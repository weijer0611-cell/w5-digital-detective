"""SAIA 2133 - W5 Digital Detective Activity
ORB feature detection + matching between two related images."""
import cv2
import numpy as np

# 1. Load both images (colour copy for drawing, greyscale for ORB)
c1 = cv2.imread("image1_mirror.jpg")
c2 = cv2.imread("image2_balloons.jpg")
img1 = cv2.cvtColor(c1, cv2.COLOR_BGR2GRAY)
img2 = cv2.cvtColor(c2, cv2.COLOR_BGR2GRAY)

# 2. Create the ORB detector (keep the 500 best keypoints)
orb = cv2.ORB_create(nfeatures=500)

# 3. Pyramid + FAST + orientation + rBRIEF
kp1, des1 = orb.detectAndCompute(img1, None)
kp2, des2 = orb.detectAndCompute(img2, None)

# 4. Brute-force matching with Hamming distance, 2 nearest neighbours
bf = cv2.BFMatcher(cv2.NORM_HAMMING)
pairs = bf.knnMatch(des1, des2, k=2)

# 5. Ratio test
good = [p[0] for p in pairs
        if len(p) == 2 and p[0].distance < 0.75 * p[1].distance]
good = sorted(good, key=lambda m: m.distance)

# 6. Save keypoint images and the final match image
cv2.imwrite("keypoints_image1.jpg", cv2.drawKeypoints(c1, kp1, None, color=(0, 255, 0),
            flags=cv2.DRAW_MATCHES_FLAGS_DRAW_RICH_KEYPOINTS))
cv2.imwrite("keypoints_image2.jpg", cv2.drawKeypoints(c2, kp2, None, color=(0, 255, 0),
            flags=cv2.DRAW_MATCHES_FLAGS_DRAW_RICH_KEYPOINTS))
out = cv2.drawMatches(c1, kp1, c2, kp2, good[:50], None,
                      flags=cv2.DrawMatchesFlags_NOT_DRAW_SINGLE_POINTS)
cv2.imwrite("result.jpg", out)

# 7. Optional: RANSAC geometric check (needs >= 4 matches)
inliers = 0
if len(good) >= 4:
    src = np.float32([kp1[m.queryIdx].pt for m in good]).reshape(-1, 1, 2)
    dst = np.float32([kp2[m.trainIdx].pt for m in good]).reshape(-1, 1, 2)
    H, mask = cv2.findHomography(src, dst, cv2.RANSAC, 5.0)
    if mask is not None:
        inliers = int(mask.sum())
        inl = [m for m, k in zip(good, mask.ravel()) if k]
        cv2.imwrite("result_ransac.jpg", cv2.drawMatches(c1, kp1, c2, kp2, inl, None,
                    flags=cv2.DrawMatchesFlags_NOT_DRAW_SINGLE_POINTS))

print("Keypoints image1:", len(kp1), "| image2:", len(kp2))
print("Descriptor shape:", des1.shape)
print("Matches before ratio test:", len(pairs))
print("Matches after ratio test :", len(good))
print("RANSAC inliers           :", inliers)
