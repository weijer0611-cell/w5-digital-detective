# SAIA 2133 – W5 Digital Detective Activity (ORB Feature Matching)

## Images used and their correlation
- `image1_mirror.jpg` – mirror selfie in a bathroom (person holding a maroon phone, grey fleece jacket, white tiles and cubicle doors).
- `image2_balloons.jpg` – selfie in a room with foil balloons (hearts and pink letters) on a wooden panel and beige wall.
- **Correlation:** both are indoor selfies of a person with long brown hair, taken with a phone in similar soft indoor lighting. Both also contain shiny, reflective surfaces (mirror/glossy tiles vs. foil balloons) and soft fabric textures (fleece jacket vs. knit cardigan).

## How to run
```
pip install opencv-python numpy
python orb_match.py
```
Outputs: `keypoints_image1.jpg`, `keypoints_image2.jpg`, `result.jpg` (matches after ratio test), `result_ransac.jpg` (RANSAC inliers).

## Pipeline (same as lecture slide)
1. Load both images as greyscale.
2. `cv2.ORB_create(nfeatures=500)`.
3. `detectAndCompute` = pyramid (8 levels, scale 1.2) -> FAST corners -> orientation -> rBRIEF 256-bit descriptor (32 bytes).
4. `BFMatcher(NORM_HAMMING)` with `knnMatch(k=2)`.
5. Ratio test: keep a match only if best distance < 0.75 x second-best.
6. Optional RANSAC homography to check geometric consistency.

## My results
| Measure | Value |
|---|---|
| Keypoints image 1 / image 2 | 500 / 500 |
| Descriptor shape | (500, 32) |
| Matches before ratio test | 500 |
| Matches after ratio test (<0.75) | 9 |
| RANSAC inliers | 5 |

## Reflection and discussion
**1. Where did the keypoints appear?**
On corners and strongly textured areas: the phone camera lenses and stickers, the ceiling lights, tile and cubicle edges, the jacket zip and drawstring in image 1; the balloon letter edges and creases, the heart balloons' bright reflections, the lace top and the wood panel edges in image 2. Flat regions such as the white ceiling, plain wall and smooth skin gave few keypoints, which matches the Corner Hunt activity (corner = good feature, flat region = bad feature).

**2. What did the ratio test do?**
It removed most of the 500 candidate matches, leaving 9. Every descriptor always gets a nearest neighbour even when nothing really corresponds, so most of those were forced guesses. The ratio test keeps only matches that clearly beat the second-best.

**3. Were the matches correct?**
Mostly no. The two photos show different scenes (a bathroom vs. a room with balloons), so there is no true correspondence. The surviving matches link things like the phone sticker or the eye area to balloon edges and the nose area, because their local intensity patterns look alike. RANSAC kept only 5 inliers, a small number that is expected to happen by chance, so it does not show a real object match.

**4. Why does ORB handle scale, rotation and lighting?**
The image pyramid handles scale, the orientation step (intensity centroid) handles rotation, and the binary rBRIEF comparisons (brighter / darker) are fairly robust to brightness changes. These help when the *same* object appears in both images, but they cannot create a match between different objects.

**5. Limitations / failure cases**
Shiny and reflective surfaces (mirror, foil balloons) change appearance with viewpoint, so their features do not repeat. Faces and soft fabric are non-rigid and low-texture, and repeated patterns (tiles, balloon creases) give ambiguous descriptors. For a clean result, use two photos of the **same object** (e.g. the same phone or the same balloon set) from different angles or distances.
